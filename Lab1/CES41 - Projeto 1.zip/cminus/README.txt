No prompt:

$ flex cminus.l
$ gcc -c *.c
$ gcc -o cminus *.o -lfl

(Em Mac pode ser que funcione com -ll no lugar de -lfl)

Executavel gerado por cminus
